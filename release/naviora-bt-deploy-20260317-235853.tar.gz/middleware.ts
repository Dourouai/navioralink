import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

import { locales } from "@/i18n/config";

const protectedSegments = new Set(["dashboard", "qrs", "analytics", "settings", "upgrade"]);

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const segments = pathname.split("/").filter(Boolean);

  if (segments.length < 2) {
    return NextResponse.next();
  }

  const [locale, section] = segments;

  if (!locales.includes(locale as (typeof locales)[number])) {
    return NextResponse.next();
  }

  if (!protectedSegments.has(section)) {
    return NextResponse.next();
  }

  return NextResponse.redirect(new URL(`/${locale}/beta`, request.url));
}

export const config = {
  matcher: ["/zh-Hant/:path*", "/en/:path*"],
};

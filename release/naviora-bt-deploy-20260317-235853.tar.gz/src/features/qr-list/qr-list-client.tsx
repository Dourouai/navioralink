"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { BarChart3, Copy, CopyPlus, Download, EllipsisVertical, Pencil, Trash2 } from "lucide-react";

import { EmptyState } from "@/components/ui/empty-state";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import type { Locale } from "@/i18n/config";
import { withLocale } from "@/i18n/config";
import { getMessages } from "@/i18n/messages";
import { formatDate, formatNumber } from "@/lib/utils";
import type { QRCodeItem, QRStatus } from "@/types/qr";

interface QrListClientProps {
  locale: Locale;
  initialItems: QRCodeItem[];
}

export function QrListClient({ locale, initialItems }: QrListClientProps) {
  const t = getMessages(locale);
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"all" | QRStatus>("all");
  const [items, setItems] = useState(initialItems);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const openMenuRef = useRef<HTMLDivElement | null>(null);
  const noticeTimerRef = useRef<number | null>(null);
  const duplicateSeedRef = useRef(1);

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchesQuery = query
        ? `${item.name} ${item.defaultUrl}`.toLowerCase().includes(query.toLowerCase())
        : true;
      const matchesStatus = status === "all" ? true : item.status === status;
      return matchesQuery && matchesStatus;
    });
  }, [items, query, status]);

  function showNotice(message: string) {
    setNotice(message);
    if (noticeTimerRef.current) {
      window.clearTimeout(noticeTimerRef.current);
    }
    noticeTimerRef.current = window.setTimeout(() => setNotice(null), 1800);
  }

  useEffect(() => {
    function handlePointerDown(event: PointerEvent) {
      if (!openMenuRef.current) return;
      if (!openMenuRef.current.contains(event.target as Node)) {
        setOpenMenuId(null);
      }
    }

    document.addEventListener("pointerdown", handlePointerDown);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      if (noticeTimerRef.current) {
        window.clearTimeout(noticeTimerRef.current);
      }
    };
  }, []);

  function sanitizeFileName(raw: string) {
    const safe = raw.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    return safe || "qr";
  }

  function hashSeed(value: string) {
    return Array.from(value).reduce((sum, char, index) => sum + char.charCodeAt(0) * (index + 1), 0);
  }

  function buildQrSvg(item: QRCodeItem) {
    const size = 29;
    const cell = 10;
    const padding = 24;
    const canvasSize = size * cell + padding * 2;
    const foreground = item.design?.borderColor ?? "#0f172a";
    const background = item.design?.backgroundColor ?? "#ffffff";
    const seed = hashSeed(`${item.id}-${item.defaultUrl}`);

    function isFinder(x: number, y: number) {
      const topLeft = x <= 6 && y <= 6;
      const topRight = x >= size - 7 && y <= 6;
      const bottomLeft = x <= 6 && y >= size - 7;
      return topLeft || topRight || bottomLeft;
    }

    function finderRect(x: number, y: number) {
      const startX = x <= 6 ? 0 : size - 7;
      const startY = y <= 6 ? 0 : size - 7;
      if (x === startX || x === startX + 6 || y === startY || y === startY + 6) return true;
      if (x >= startX + 2 && x <= startX + 4 && y >= startY + 2 && y <= startY + 4) return true;
      return false;
    }

    let rects = "";
    for (let y = 0; y < size; y += 1) {
      for (let x = 0; x < size; x += 1) {
        const shouldFill = isFinder(x, y) ? finderRect(x, y) : ((x * 17 + y * 31 + seed) % 7 < 3);
        if (!shouldFill) continue;
        rects += `<rect x="${padding + x * cell}" y="${padding + y * cell}" width="${cell - 1}" height="${cell - 1}" rx="2" fill="${foreground}" />`;
      }
    }

    return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${canvasSize}" height="${canvasSize}" viewBox="0 0 ${canvasSize} ${canvasSize}" role="img" aria-label="${item.name}">
  <rect width="${canvasSize}" height="${canvasSize}" rx="36" fill="${background}" />
  ${rects}
</svg>`;
  }

  function downloadItem(item: QRCodeItem) {
    const blob = new Blob([buildQrSvg(item)], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${sanitizeFileName(item.name)}-qr.svg`;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setOpenMenuId(null);
    showNotice(locale === "zh-Hant" ? "已開始下載二維碼。" : "QR code download started.");
  }

  async function copyUrl(item: QRCodeItem) {
    try {
      await navigator.clipboard.writeText(item.defaultUrl);
      showNotice(locale === "zh-Hant" ? "已複製網址。" : "URL copied.");
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = item.defaultUrl;
      textarea.setAttribute("readonly", "");
      textarea.style.position = "absolute";
      textarea.style.left = "-9999px";
      document.body.append(textarea);
      textarea.select();
      document.execCommand("copy");
      textarea.remove();
      showNotice(locale === "zh-Hant" ? "已複製網址。" : "URL copied.");
    }
  }

  function editItem(item: QRCodeItem) {
    setOpenMenuId(null);
    router.push(withLocale(locale, `/qrs/new?edit=${encodeURIComponent(item.id)}`));
  }

  function viewAnalytics(item: QRCodeItem) {
    setOpenMenuId(null);
    router.push(withLocale(locale, `/qrs/${encodeURIComponent(item.id)}/analytics`));
  }

  function duplicateItem(item: QRCodeItem) {
    const now = new Date().toISOString();
    const duplicateId = `${item.id}_copy_${duplicateSeedRef.current}`;
    duplicateSeedRef.current += 1;
    const duplicated: QRCodeItem = {
      ...item,
      id: duplicateId,
      name: locale === "zh-Hant" ? `${item.name}（副本）` : `${item.name} (Copy)`,
      status: "draft",
      scans: 0,
      createdAt: now,
      updatedAt: now,
      languageRules: item.languageRules?.map((rule) => ({ ...rule })),
      regionRules: item.regionRules?.map((rule) => ({ ...rule })),
      tracking: item.tracking ? { ...item.tracking } : undefined,
      design: item.design ? { ...item.design } : undefined,
    };
    setItems((current) => [duplicated, ...current]);
    setOpenMenuId(null);
    showNotice(locale === "zh-Hant" ? "已建立副本。" : "Duplicate created.");
  }

  function removeItem(id: string) {
    const confirmed = window.confirm(locale === "zh-Hant" ? "確定要刪除這個 QR 嗎？" : "Delete this QR?");
    if (!confirmed) return;
    setItems((current) => current.filter((item) => item.id !== id));
    setOpenMenuId(null);
    showNotice(locale === "zh-Hant" ? "已刪除。" : "Deleted.");
  }

  return (
    <Card className="space-y-5">
      {notice ? (
        <div className="rounded-[16px] bg-emerald-50 px-4 py-2.5 text-sm text-emerald-700 ring-1 ring-emerald-100">
          {notice}
        </div>
      ) : null}
      <div className="grid gap-4 md:grid-cols-[1fr_auto]">
        <Input label={t.common.search} placeholder={t.qrs.searchPlaceholder} value={query} onChange={(event) => setQuery(event.target.value)} />
        <div className="flex flex-wrap items-end gap-2">
          {(["all", "draft", "active", "expired"] as const).map((item) => (
            <Button
              key={item}
              variant={status === item ? "primary" : "secondary"}
              className="mt-7"
              onClick={() => setStatus(item)}
            >
              {item === "all" ? t.common.all : t.common[item]}
            </Button>
          ))}
        </div>
      </div>
      {filteredItems.length ? (
        <div className="overflow-hidden rounded-[22px] border border-slate-100">
          <div className="hidden grid-cols-[1.2fr_1.1fr_120px_120px_120px_80px] gap-4 bg-slate-50 px-5 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-slate-400 lg:grid">
            <div>Name</div>
            <div>Default URL</div>
            <div>{t.common.type}</div>
            <div>{t.common.scans}</div>
            <div>{t.common.updatedAt}</div>
            <div className="text-right">{t.common.actions}</div>
          </div>
          {filteredItems.map((item) => (
            <div key={item.id} className="grid gap-4 border-t border-slate-100 bg-white px-5 py-4 lg:grid-cols-[1.2fr_1.1fr_120px_120px_120px_80px] lg:items-center">
              <div>
                <div className="text-sm font-semibold text-slate-900">{item.name}</div>
                <div className="mt-1 text-xs text-slate-500">{item.ruleMode}</div>
              </div>
              <div className="flex items-center gap-2">
                <div className="min-w-0 truncate text-sm text-slate-600">{item.defaultUrl}</div>
                <button
                  type="button"
                  onClick={() => copyUrl(item)}
                  className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white ring-1 ring-[rgba(190,206,226,0.6)] transition hover:bg-slate-50"
                  aria-label={t.common.copy}
                  title={t.common.copy}
                >
                  <Copy size={14} className="text-slate-500" />
                </button>
              </div>
              <div className="text-sm text-slate-600">{item.type.toUpperCase()}</div>
              <div className="text-sm text-slate-600">{formatNumber(item.scans)}</div>
              <div className="text-sm text-slate-600">{formatDate(item.updatedAt)}</div>
              <div className="relative ml-auto">
                <button
                  type="button"
                  onClick={() => setOpenMenuId((current) => (current === item.id ? null : item.id))}
                  className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white ring-1 ring-[rgba(190,206,226,0.6)] transition hover:bg-slate-50"
                  aria-label={t.common.actions}
                >
                  <EllipsisVertical size={16} className="text-slate-600" />
                </button>

                {openMenuId === item.id ? (
                  <div
                    ref={openMenuRef}
                    className="absolute right-0 top-11 z-30 w-48 overflow-hidden rounded-[16px] bg-white py-1.5 shadow-[0_18px_36px_rgba(15,23,42,0.12)] ring-1 ring-[rgba(190,206,226,0.55)]"
                  >
                    <button
                      type="button"
                      onClick={() => viewAnalytics(item)}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                    >
                      <BarChart3 size={15} />
                      {t.analytics.viewEntry}
                    </button>
                    <button
                      type="button"
                      onClick={() => downloadItem(item)}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                    >
                      <Download size={15} />
                      {t.common.download}
                    </button>
                    <button
                      type="button"
                      onClick={() => editItem(item)}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                    >
                      <Pencil size={15} />
                      {t.common.edit}
                    </button>
                    <button
                      type="button"
                      onClick={() => duplicateItem(item)}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-sm text-slate-700 transition hover:bg-slate-50"
                    >
                      <CopyPlus size={15} />
                      {t.common.duplicate}
                    </button>
                    <button
                      type="button"
                      onClick={() => removeItem(item.id)}
                      className="flex w-full items-center gap-2.5 px-3 py-2 text-sm text-rose-600 transition hover:bg-rose-50"
                    >
                      <Trash2 size={15} />
                      {t.common.delete}
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title={t.qrs.emptyTitle} body={t.qrs.emptyBody} href={withLocale(locale, "/qrs/new")} actionLabel={t.nav.create} />
      )}
    </Card>
  );
}

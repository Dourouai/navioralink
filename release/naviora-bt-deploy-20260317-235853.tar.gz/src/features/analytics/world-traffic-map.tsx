import { Badge } from "@/components/ui/badge";

interface WorldTrafficMapProps {
  title: string;
  body: string;
  locale: string;
  scansLabel: string;
  rows: Array<{ label: string; scans: number; share: string }>;
}

type GeoPoint = [number, number];

const VIEWBOX_WIDTH = 800;
const VIEWBOX_HEIGHT = 420;
const MAP_PADDING = 28;
const LAT_MAX = 85;
const LAT_MIN = -60;

const regionCoordinates: Record<string, GeoPoint> = {
  "United States": [-98, 39],
  Japan: [138, 36],
  Taiwan: [121, 23.7],
  "Hong Kong": [114.2, 22.3],
  Singapore: [103.8, 1.35],
};

const continentShapes: GeoPoint[][] = [
  [
    [-168, 72],
    [-148, 73],
    [-132, 69],
    [-122, 60],
    [-126, 51],
    [-122, 42],
    [-118, 34],
    [-111, 27],
    [-104, 21],
    [-96, 18],
    [-87, 18],
    [-81, 24],
    [-78, 31],
    [-71, 41],
    [-64, 50],
    [-58, 57],
    [-62, 64],
    [-76, 70],
    [-100, 74],
    [-130, 75],
    [-155, 74],
  ],
  [
    [-82, 12],
    [-77, 8],
    [-74, 0],
    [-71, -8],
    [-68, -18],
    [-65, -30],
    [-60, -42],
    [-54, -50],
    [-47, -55],
    [-40, -51],
    [-38, -40],
    [-41, -27],
    [-47, -12],
    [-55, -2],
    [-64, 6],
    [-73, 11],
  ],
  [
    [-12, 71],
    [2, 72],
    [18, 68],
    [31, 62],
    [35, 55],
    [29, 49],
    [18, 45],
    [8, 42],
    [-1, 43],
    [-8, 49],
    [-13, 57],
    [-16, 65],
  ],
  [
    [-18, 35],
    [-6, 37],
    [8, 35],
    [22, 31],
    [31, 24],
    [38, 12],
    [41, -1],
    [40, -14],
    [33, -26],
    [23, -34],
    [10, -35],
    [0, -28],
    [-8, -16],
    [-12, -2],
    [-15, 15],
    [-18, 27],
  ],
  [
    [32, 72],
    [48, 73],
    [68, 71],
    [92, 67],
    [114, 60],
    [132, 51],
    [149, 41],
    [159, 30],
    [157, 17],
    [147, 8],
    [130, 3],
    [114, -1],
    [96, 5],
    [82, 14],
    [70, 21],
    [58, 27],
    [48, 34],
    [40, 45],
    [34, 56],
  ],
  [
    [66, 24],
    [79, 26],
    [88, 22],
    [94, 16],
    [98, 9],
    [101, 2],
    [105, 4],
    [108, 10],
    [106, 18],
    [98, 23],
    [88, 25],
    [78, 25],
  ],
  [
    [112, -11],
    [124, -14],
    [138, -18],
    [150, -26],
    [153, -36],
    [146, -42],
    [131, -44],
    [118, -41],
    [112, -31],
  ],
  [
    [-58, 79],
    [-44, 77],
    [-33, 72],
    [-36, 64],
    [-46, 61],
    [-57, 65],
    [-62, 72],
  ],
  [
    [138, 45],
    [143, 42],
    [145, 37],
    [141, 33],
    [137, 36],
  ],
];

function projectPoint([lon, lat]: GeoPoint) {
  const x = MAP_PADDING + ((lon + 180) / 360) * (VIEWBOX_WIDTH - MAP_PADDING * 2);
  const y = MAP_PADDING + ((LAT_MAX - lat) / (LAT_MAX - LAT_MIN)) * (VIEWBOX_HEIGHT - MAP_PADDING * 2);
  return { x, y };
}

function buildPath(points: GeoPoint[]) {
  return points
    .map((point, index) => {
      const { x, y } = projectPoint(point);
      return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ")
    .concat(" Z");
}

function buildRoutePath(from: { x: number; y: number }, to: { x: number; y: number }) {
  const controlX = (from.x + to.x) / 2;
  const controlY = Math.min(from.y, to.y) - Math.max(18, Math.abs(from.x - to.x) * 0.08);
  return `M${from.x.toFixed(1)} ${from.y.toFixed(1)} Q${controlX.toFixed(1)} ${controlY.toFixed(1)} ${to.x.toFixed(1)} ${to.y.toFixed(1)}`;
}

export function WorldTrafficMap({ title, body, locale, scansLabel, rows }: WorldTrafficMapProps) {
  const topRows = rows.slice(0, 5);
  const maxScans = Math.max(...topRows.map((row) => row.scans), 1);

  const weightedCenter = topRows.reduce(
    (acc, row) => {
      const coordinate = regionCoordinates[row.label];
      if (!coordinate) return acc;
      return {
        lon: acc.lon + coordinate[0] * row.scans,
        lat: acc.lat + coordinate[1] * row.scans,
        weight: acc.weight + row.scans,
      };
    },
    { lon: 0, lat: 0, weight: 0 },
  );

  const centerPoint = projectPoint(
    weightedCenter.weight > 0 ? [weightedCenter.lon / weightedCenter.weight, weightedCenter.lat / weightedCenter.weight] : [110, 20],
  );

  return (
    <div className="rounded-[30px] bg-[linear-gradient(180deg,rgba(255,255,255,0.96),rgba(247,251,255,0.98))] p-5 ring-1 ring-[rgba(190,206,226,0.45)]">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">{title}</h2>
          <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-500">{body}</p>
        </div>
        <Badge tone="info">{rows.length}</Badge>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="overflow-hidden rounded-[26px] bg-[linear-gradient(145deg,#13233a_0%,#1d3150_56%,#12213a_100%)] p-4 shadow-[0_24px_48px_rgba(15,23,42,0.18)]">
          <svg viewBox={`0 0 ${VIEWBOX_WIDTH} ${VIEWBOX_HEIGHT}`} className="h-full w-full">
            <defs>
              <linearGradient id="worldGlow" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#1abef3" stopOpacity="0.16" />
                <stop offset="100%" stopColor="#8d79ff" stopOpacity="0.26" />
              </linearGradient>
              <linearGradient id="routeLine" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#22c7f5" stopOpacity="0.28" />
                <stop offset="45%" stopColor="#61a9ff" stopOpacity="0.88" />
                <stop offset="100%" stopColor="#8c7cff" stopOpacity="0.28" />
              </linearGradient>
            </defs>

            <rect width={VIEWBOX_WIDTH} height={VIEWBOX_HEIGHT} rx="28" fill="url(#worldGlow)" />

            {Array.from({ length: 9 }, (_, index) => (
              <line
                key={`h-${index}`}
                x1="0"
                y1={40 + index * 40}
                x2={VIEWBOX_WIDTH}
                y2={40 + index * 40}
                stroke="rgba(255,255,255,0.08)"
                strokeDasharray="4 8"
              />
            ))}
            {Array.from({ length: 11 }, (_, index) => (
              <line
                key={`v-${index}`}
                x1={40 + index * 70}
                y1="0"
                x2={40 + index * 70}
                y2={VIEWBOX_HEIGHT}
                stroke="rgba(255,255,255,0.06)"
                strokeDasharray="4 10"
              />
            ))}

            {continentShapes.map((shape, index) => (
              <path
                key={index}
                d={buildPath(shape)}
                fill={index % 2 === 0 ? "rgba(148,205,255,0.18)" : "rgba(188,182,255,0.14)"}
                stroke="rgba(255,255,255,0.18)"
                strokeWidth="1.15"
                strokeLinejoin="round"
              />
            ))}

            {topRows.map((row) => {
              const coordinate = regionCoordinates[row.label];
              if (!coordinate) return null;

              const position = projectPoint(coordinate);
              const radius = 8 + (row.scans / maxScans) * 14;

              return (
                <g key={row.label}>
                  <path d={buildRoutePath(centerPoint, position)} stroke="url(#routeLine)" strokeWidth="2.4" strokeLinecap="round" fill="none" />
                  <circle cx={position.x} cy={position.y} r={radius + 10} fill="rgba(33,189,241,0.12)" />
                  <circle cx={position.x} cy={position.y} r={radius} fill={row.label === topRows[0]?.label ? "#8d79ff" : "#20c2f3"} fillOpacity="0.94" />
                  <circle cx={position.x} cy={position.y} r="3.2" fill="#ffffff" />
                </g>
              );
            })}

            <circle cx={centerPoint.x} cy={centerPoint.y} r="14" fill="#ffffff" fillOpacity="0.14" />
            <circle cx={centerPoint.x} cy={centerPoint.y} r="8" fill="#ffffff" fillOpacity="0.92" />
          </svg>
        </div>

        <div className="space-y-3">
          {topRows.map((row, index) => (
            <div key={row.label} className="rounded-[22px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span
                    className="inline-flex h-8 w-8 items-center justify-center rounded-full text-xs font-semibold text-white"
                    style={{ background: index === 0 ? "linear-gradient(135deg,#8d79ff 0%,#5f95ff 100%)" : "linear-gradient(135deg,#1abef3 0%,#3f8cff 100%)" }}
                  >
                    {index + 1}
                  </span>
                  <div className="text-sm font-semibold text-slate-900">{row.label}</div>
                </div>
                <Badge tone="info">{row.share}</Badge>
              </div>
              <div className="mt-2 text-sm text-slate-500">
                {new Intl.NumberFormat(locale).format(row.scans)} {scansLabel}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { CreditCard, KeyRound, Mail, ReceiptText, ShieldCheck } from "lucide-react";
import { useState } from "react";

import { PageHeader } from "@/components/shared/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import type { Locale } from "@/i18n/config";
import { withLocale } from "@/i18n/config";
import { getMessages } from "@/i18n/messages";
import { updateAccountEmail, updateAccountPassword } from "@/lib/services";
import { currentPlan, billingHistory } from "@/mock/billing";
import { useAuthStore } from "@/store/auth-store";

interface SettingsCenterProps {
  locale: Locale;
}

function formatDate(value: string, locale: Locale) {
  return new Intl.DateTimeFormat(locale === "zh-Hant" ? "zh-Hant" : "en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(new Date(value));
}

function formatCurrency(value: number, currency: string, locale: Locale) {
  return new Intl.NumberFormat(locale === "zh-Hant" ? "zh-Hant" : "en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(value);
}

function formatUsageValue(value: number, type: "default" | "storage", locale: Locale) {
  if (type === "storage") {
    return `${value} MB`;
  }

  return new Intl.NumberFormat(locale === "zh-Hant" ? "zh-Hant" : "en-US").format(value);
}

export function SettingsCenter({ locale }: SettingsCenterProps) {
  const t = getMessages(locale);
  const user = useAuthStore((state) => state.user);
  const updateUser = useAuthStore((state) => state.updateUser);

  const [newEmail, setNewEmail] = useState(user?.email ?? "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [nextPassword, setNextPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [emailSuccess, setEmailSuccess] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [emailPending, setEmailPending] = useState(false);
  const [passwordPending, setPasswordPending] = useState(false);

  const currentEmail = user?.email ?? "hello@naviora.com";
  const accountName = user?.name ?? "Naviora User";
  const usageItems = [
    {
      label: t.settings.usageEntries,
      used: currentPlan.usage.entries.used,
      limit: currentPlan.usage.entries.limit,
      type: "default" as const,
    },
    {
      label: t.settings.usageAiConversations,
      used: currentPlan.usage.aiConversations.used,
      limit: currentPlan.usage.aiConversations.limit,
      type: "default" as const,
    },
    {
      label: t.settings.usageMonthlyVisits,
      used: currentPlan.usage.monthlyVisits.used,
      limit: currentPlan.usage.monthlyVisits.limit,
      type: "default" as const,
    },
    {
      label: t.settings.usageStorage,
      used: currentPlan.usage.storageMb.used,
      limit: currentPlan.usage.storageMb.limit,
      type: "storage" as const,
    },
  ];

  async function handleEmailSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setEmailError("");
    setEmailSuccess("");

    const normalizedEmail = newEmail.trim();
    const isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail);

    if (!isValidEmail) {
      setEmailError(t.settings.emailInvalid);
      return;
    }

    if (normalizedEmail.toLowerCase() === currentEmail.toLowerCase()) {
      setEmailError(t.settings.emailSame);
      return;
    }

    setEmailPending(true);
    try {
      await updateAccountEmail(normalizedEmail);
      updateUser({ email: normalizedEmail });
      setEmailSuccess(t.settings.emailUpdated);
    } finally {
      setEmailPending(false);
    }
  }

  async function handlePasswordSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPasswordError("");
    setPasswordSuccess("");

    if (!currentPassword.trim()) {
      setPasswordError(t.settings.currentPasswordRequired);
      return;
    }

    if (nextPassword.length < 8) {
      setPasswordError(t.settings.passwordTooShort);
      return;
    }

    if (nextPassword !== confirmPassword) {
      setPasswordError(t.settings.passwordMismatch);
      return;
    }

    setPasswordPending(true);
    try {
      await updateAccountPassword();
      setCurrentPassword("");
      setNextPassword("");
      setConfirmPassword("");
      setPasswordSuccess(t.settings.passwordUpdated);
    } finally {
      setPasswordPending(false);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        badge={t.common.settings}
        title={t.settings.title}
        description={t.settings.subtitle}
        actions={
          <>
            <Link href={withLocale(locale, "/upgrade")}>
              <Button variant="secondary">{t.settings.managePlan}</Button>
            </Link>
            <Link href={withLocale(locale, "/about")}>
              <Button>{t.settings.contactSales}</Button>
            </Link>
          </>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        <Card className="space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-lg font-semibold text-slate-900">
                <ShieldCheck size={18} className="text-emerald-600" />
                {t.settings.overviewTitle}
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-500">{t.settings.overviewBody}</p>
            </div>
            <Badge tone="success">{t.settings.verifiedStatus}</Badge>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-[22px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.5)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.settings.accountName}</div>
              <div className="mt-2 text-lg font-semibold text-slate-900">{accountName}</div>
            </div>
            <div className="rounded-[22px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.5)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.settings.accountEmail}</div>
              <div className="mt-2 text-lg font-semibold text-slate-900">{currentEmail}</div>
            </div>
            <div className="rounded-[22px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.5)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.settings.memberSince}</div>
              <div className="mt-2 text-lg font-semibold text-slate-900">{formatDate(user?.createdAt ?? "2026-03-16T08:00:00.000Z", locale)}</div>
            </div>
            <div className="rounded-[22px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.5)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.settings.accountStatus}</div>
              <div className="mt-2 text-lg font-semibold text-slate-900">{t.settings.verifiedStatus}</div>
            </div>
          </div>

          <div className="rounded-[24px] bg-[linear-gradient(135deg,rgba(236,251,255,0.96),rgba(244,240,255,0.94))] p-5 ring-1 ring-[rgba(174,206,241,0.42)]">
            <div className="text-sm font-semibold text-slate-900">{t.settings.securityTitle}</div>
            <p className="mt-2 text-sm leading-6 text-slate-600">{t.settings.securityBody}</p>
          </div>
        </Card>

        <Card className="space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-lg font-semibold text-slate-900">
                <CreditCard size={18} className="text-sky-600" />
                {t.settings.currentPlanTitle}
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-500">{t.settings.currentPlanBody}</p>
            </div>
            <Badge tone="info">{currentPlan.name}</Badge>
          </div>

          <div className="rounded-[24px] bg-[linear-gradient(165deg,#121c2f_0%,#1a2b45_60%,#131f36_100%)] p-5 text-white shadow-[0_20px_40px_rgba(15,23,42,0.16)]">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-[0.12em] text-sky-200">{t.settings.currentPlanLabel}</div>
                <div className="mt-2 text-3xl font-semibold">{currentPlan.name}</div>
              </div>
              <div className="text-right">
                <div className="text-sm text-slate-300">{t.settings.billingCycle}</div>
                <div className="mt-2 text-xl font-semibold">
                  {formatCurrency(currentPlan.price, currentPlan.currency, locale)} / {currentPlan.billingCycle === "monthly" ? t.settings.monthly : t.settings.yearly}
                </div>
              </div>
            </div>

            <div className="mt-6 grid gap-3 md:grid-cols-2">
              <div className="rounded-[18px] bg-white/10 px-4 py-3 ring-1 ring-white/12">
                <div className="text-xs uppercase tracking-[0.12em] text-slate-300">{t.settings.renewalDate}</div>
                <div className="mt-2 text-sm font-semibold text-white">{formatDate(currentPlan.renewalDate, locale)}</div>
              </div>
              <div className="rounded-[18px] bg-white/10 px-4 py-3 ring-1 ring-white/12">
                <div className="text-xs uppercase tracking-[0.12em] text-slate-300">{t.settings.paymentMethod}</div>
                <div className="mt-2 text-sm font-semibold text-white">{currentPlan.paymentMethod}</div>
              </div>
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold text-slate-900">{t.settings.usageTitle}</div>
            <div className="mt-4 space-y-4">
              {usageItems.map((item) => {
                const progress = Math.min(100, Math.round((item.used / item.limit) * 100));
                return (
                  <div key={item.label}>
                    <div className="mb-2 flex items-center justify-between gap-4 text-sm">
                      <span className="font-medium text-slate-700">{item.label}</span>
                      <span className="text-slate-500">
                        {formatUsageValue(item.used, item.type, locale)} / {formatUsageValue(item.limit, item.type, locale)}
                      </span>
                    </div>
                    <div className="h-2.5 rounded-full bg-slate-100">
                      <div className="h-2.5 rounded-full bg-[linear-gradient(135deg,#1abef3_0%,#3f8cff_58%,#8d79ff_100%)]" style={{ width: `${progress}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card className="space-y-5">
          <div className="flex items-center gap-2 text-lg font-semibold text-slate-900">
            <Mail size={18} className="text-sky-600" />
            {t.settings.emailTitle}
          </div>
          <p className="text-sm leading-6 text-slate-500">{t.settings.emailBody}</p>

          <form className="space-y-4" onSubmit={handleEmailSubmit}>
            <Input label={t.settings.currentEmail} value={currentEmail} disabled className="h-12 rounded-[16px]" />
            <Input
              label={t.settings.newEmail}
              type="email"
              value={newEmail}
              onChange={(event) => setNewEmail(event.target.value)}
              placeholder="name@company.com"
              error={emailError || undefined}
              className="h-12 rounded-[16px]"
            />
            {emailSuccess ? <div className="rounded-[18px] bg-emerald-50 px-4 py-3 text-sm text-emerald-700 ring-1 ring-emerald-100">{emailSuccess}</div> : null}
            <Button type="submit" disabled={emailPending}>
              {emailPending ? t.common.loading : t.settings.saveEmail}
            </Button>
          </form>
        </Card>

        <Card className="space-y-5">
          <div className="flex items-center gap-2 text-lg font-semibold text-slate-900">
            <KeyRound size={18} className="text-violet-600" />
            {t.settings.passwordTitle}
          </div>
          <p className="text-sm leading-6 text-slate-500">{t.settings.passwordBody}</p>

          <form className="space-y-4" onSubmit={handlePasswordSubmit}>
            <Input
              label={t.settings.currentPassword}
              type="password"
              value={currentPassword}
              onChange={(event) => setCurrentPassword(event.target.value)}
              className="h-12 rounded-[16px]"
            />
            <Input
              label={t.settings.newPassword}
              type="password"
              value={nextPassword}
              onChange={(event) => setNextPassword(event.target.value)}
              error={passwordError || undefined}
              className="h-12 rounded-[16px]"
            />
            <Input
              label={t.settings.confirmNewPassword}
              type="password"
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
              className="h-12 rounded-[16px]"
            />
            {passwordSuccess ? <div className="rounded-[18px] bg-emerald-50 px-4 py-3 text-sm text-emerald-700 ring-1 ring-emerald-100">{passwordSuccess}</div> : null}
            <Button type="submit" disabled={passwordPending}>
              {passwordPending ? t.common.loading : t.settings.savePassword}
            </Button>
          </form>
        </Card>
      </div>

      <Card className="space-y-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-lg font-semibold text-slate-900">
              <ReceiptText size={18} className="text-amber-600" />
              {t.settings.billingHistoryTitle}
            </div>
            <p className="mt-2 text-sm leading-6 text-slate-500">{t.settings.billingHistoryBody}</p>
          </div>
          <Badge tone="default">{billingHistory.length}</Badge>
        </div>

        <div className="overflow-hidden rounded-[24px] border border-slate-100 bg-white/90">
          <div className="hidden grid-cols-[1.2fr_1fr_0.8fr_0.7fr] gap-3 border-b border-slate-100 px-5 py-3 text-xs uppercase tracking-[0.14em] text-slate-400 md:grid">
            <div>{t.settings.invoiceNumber}</div>
            <div>{t.settings.invoiceDate}</div>
            <div>{t.settings.invoiceAmount}</div>
            <div>{t.settings.invoiceStatus}</div>
          </div>

          {billingHistory.map((invoice) => {
            const statusTone: "default" | "success" | "danger" = invoice.status === "paid" ? "success" : invoice.status === "failed" ? "danger" : "default";
            const statusLabel = invoice.status === "paid" ? t.settings.paid : invoice.status === "failed" ? t.settings.failed : t.settings.pending;

            return (
              <div
                key={invoice.id}
                className="grid gap-3 border-t border-slate-100 px-5 py-4 text-sm text-slate-700 md:grid-cols-[1.2fr_1fr_0.8fr_0.7fr] md:items-center"
              >
                <div className="font-semibold text-slate-900">{invoice.id}</div>
                <div>{formatDate(invoice.issuedAt, locale)}</div>
                <div>{formatCurrency(invoice.amount, invoice.currency, locale)}</div>
                <div>
                  <Badge tone={statusTone}>{statusLabel}</Badge>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

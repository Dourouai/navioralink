import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";

import { AnalyticsChart } from "@/features/analytics/analytics-chart";
import { BreakdownBarChart } from "@/features/analytics/breakdown-bar-chart";
import { BreakdownDonutChart } from "@/features/analytics/breakdown-donut-chart";
import { WorldTrafficMap } from "@/features/analytics/world-traffic-map";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import type { Locale } from "@/i18n/config";
import { withLocale } from "@/i18n/config";
import { getMessages } from "@/i18n/messages";
import { buildEntryAnalyticsMetadata } from "@/lib/metadata";
import { entryAnalyticsById } from "@/mock/entry-analytics";
import { mockQrList } from "@/mock/qrs";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: Locale; id: string }>;
}): Promise<Metadata> {
  const { locale, id } = await params;
  const item = mockQrList.find((entry) => entry.id === id);

  if (!item) {
    return locale === "zh-Hant"
      ? { title: "入口分析 | Naviora", description: "查看智能入口的掃碼趨勢、分布與分析資料。" }
      : { title: "Entry Analytics | Naviora", description: "Review scan trends, breakdowns, and analytics for a smart entry." };
  }

  return buildEntryAnalyticsMetadata(locale, item.name);
}

function formatDate(value: string, locale: Locale, withTime = false) {
  return new Intl.DateTimeFormat(locale === "zh-Hant" ? "zh-Hant" : "en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  }).format(new Date(value));
}

function formatNumber(value: number, locale: Locale) {
  return new Intl.NumberFormat(locale === "zh-Hant" ? "zh-Hant" : "en-US").format(value);
}

export default async function EntryAnalyticsPage({
  params,
}: {
  params: Promise<{ locale: Locale; id: string }>;
}) {
  const { locale, id } = await params;
  const t = getMessages(locale);
  const item = mockQrList.find((entry) => entry.id === id);
  const analytics = entryAnalyticsById[id];

  if (!item || !analytics) {
    notFound();
  }

  const ruleModeLabel =
    locale === "zh-Hant"
      ? { none: "無規則", language: "語言模式", region: "國家或地區模式" }
      : { none: "No rule", language: "Language", region: "Region" };

  return (
    <div className="space-y-6">
      <PageHeader
        badge={t.analytics.entryBadge}
        title={item.name}
        description={t.analytics.entrySubtitle}
        actions={
          <Link href={withLocale(locale, "/qrs")}>
            <Button variant="secondary">{t.analytics.backToList}</Button>
          </Link>
        }
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard label={t.analytics.total} value={formatNumber(analytics.totalScans, locale)} />
        <StatCard label={t.analytics.today} value={formatNumber(analytics.todayScans, locale)} />
        <StatCard label={t.analytics.uniqueVisitors} value={formatNumber(analytics.uniqueVisitors, locale)} />
        <StatCard label={t.analytics.conversionRate} value={analytics.conversionRate} />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
        <Card>
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-xl font-semibold text-slate-900">{t.analytics.chartTitle}</h2>
              <p className="mt-1 text-sm text-slate-500">
                {t.analytics.lastScan}: {formatDate(analytics.lastScan, locale, true)}
              </p>
            </div>
            <Badge tone={item.status === "active" ? "success" : item.status === "draft" ? "default" : "danger"}>{t.common[item.status]}</Badge>
          </div>
          <div className="mt-5">
            <AnalyticsChart data={analytics.trendData} />
          </div>
        </Card>

        <Card className="space-y-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900">{t.analytics.routingSnapshot}</h2>
            <p className="mt-1 text-sm text-slate-500">{item.defaultUrl}</p>
          </div>

          <div className="grid gap-3">
            <div className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.analytics.topRegion}</div>
              <div className="mt-2 text-base font-semibold text-slate-900">{analytics.topRegion}</div>
            </div>
            <div className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.analytics.topDevice}</div>
              <div className="mt-2 text-base font-semibold text-slate-900">{analytics.topDevice}</div>
            </div>
            <div className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.analytics.topOs}</div>
              <div className="mt-2 text-base font-semibold text-slate-900">{analytics.topOs}</div>
            </div>
            <div className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
              <div className="text-xs uppercase tracking-[0.12em] text-slate-400">{t.analytics.topLanguage}</div>
              <div className="mt-2 text-base font-semibold text-slate-900">{analytics.topLanguage}</div>
            </div>
          </div>

          <div className="space-y-3 rounded-[24px] bg-[linear-gradient(180deg,rgba(255,255,255,0.94),rgba(247,251,255,0.96))] p-5 ring-1 ring-[rgba(190,206,226,0.45)]">
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm text-slate-500">{t.analytics.defaultUrl}</span>
              <span className="text-sm font-medium text-slate-900">{item.type.toUpperCase()}</span>
            </div>
            <div className="text-sm text-slate-700 break-all">{item.defaultUrl}</div>
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <div className="text-sm text-slate-500">{t.analytics.ruleMode}</div>
                <div className="mt-1 text-sm font-medium text-slate-900">{ruleModeLabel[item.ruleMode]}</div>
              </div>
              <div>
                <div className="text-sm text-slate-500">{t.analytics.statusLabel}</div>
                <div className="mt-1 text-sm font-medium text-slate-900">{t.common[item.status]}</div>
              </div>
              <div>
                <div className="text-sm text-slate-500">{t.analytics.createdAt}</div>
                <div className="mt-1 text-sm font-medium text-slate-900">{formatDate(item.createdAt, locale)}</div>
              </div>
              <div>
                <div className="text-sm text-slate-500">{t.analytics.trackingStatus}</div>
                <div className="mt-1 text-sm font-medium text-slate-900">
                  {item.tracking?.enabled ? t.analytics.trackingEnabled : t.analytics.trackingDisabled}
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <WorldTrafficMap
        title={t.analytics.globalMapTitle}
        body={t.analytics.globalMapBody}
        locale={locale === "zh-Hant" ? "zh-Hant" : "en-US"}
        scansLabel={t.common.scans}
        rows={analytics.regionData}
      />

      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <Card>
          <h2 className="text-xl font-semibold text-slate-900">{t.analytics.regionBreakdown}</h2>
          <div className="mt-5">
            <BreakdownBarChart data={analytics.regionData} />
          </div>
          <div className="mt-4 space-y-3">
            {analytics.regionData.map((row) => (
              <div key={row.label} className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-slate-900">{row.label}</div>
                  <Badge tone="info">{row.share}</Badge>
                </div>
                <div className="mt-2 text-sm text-slate-500">
                  {formatNumber(row.scans, locale)} {t.common.scans}
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="text-xl font-semibold text-slate-900">{t.analytics.deviceBreakdown}</h2>
          <div className="mt-5">
            <BreakdownDonutChart data={analytics.deviceData} />
          </div>
          <div className="mt-4 space-y-3">
            {analytics.deviceData.map((row) => (
              <div key={row.label} className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-slate-900">{row.label}</div>
                  <Badge tone="info">{row.share}</Badge>
                </div>
                <div className="mt-2 text-sm text-slate-500">
                  {formatNumber(row.scans, locale)} {t.common.scans}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <h2 className="text-xl font-semibold text-slate-900">{t.analytics.osBreakdown}</h2>
          <div className="mt-5">
            <BreakdownDonutChart data={analytics.osData} />
          </div>
          <div className="mt-4 space-y-3">
            {analytics.osData.map((row) => (
              <div key={row.label} className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-slate-900">{row.label}</div>
                  <Badge tone="info">{row.share}</Badge>
                </div>
                <div className="mt-2 text-sm text-slate-500">
                  {formatNumber(row.scans, locale)} {t.common.scans}
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="text-xl font-semibold text-slate-900">{t.analytics.languageBreakdown}</h2>
          <div className="mt-5">
            <BreakdownDonutChart data={analytics.languageData} />
          </div>
          <div className="mt-4 space-y-3">
            {analytics.languageData.map((row) => (
              <div key={row.label} className="rounded-[20px] bg-white/88 p-4 ring-1 ring-[rgba(190,206,226,0.45)]">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-slate-900">{row.label}</div>
                  <Badge tone="info">{row.share}</Badge>
                </div>
                <div className="mt-2 text-sm text-slate-500">
                  {formatNumber(row.scans, locale)} {t.common.scans}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

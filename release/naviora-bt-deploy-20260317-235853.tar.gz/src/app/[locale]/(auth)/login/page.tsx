import type { Metadata } from "next";
import { redirect } from "next/navigation";

import type { Locale } from "@/i18n/config";
import { withLocale } from "@/i18n/config";

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  return {
    title: locale === "zh-Hant" ? "跳轉中 | Naviora" : "Redirecting | Naviora",
  };
}

export default async function LoginPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  redirect(withLocale(locale, "/beta"));
}

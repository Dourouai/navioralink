import type { Metadata } from "next";
import Link from "next/link";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import type { Locale } from "@/i18n/config";
import { withLocale } from "@/i18n/config";
import { buildPageMetadata } from "@/lib/metadata";

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  return buildPageMetadata(locale, "terms");
}

export default async function TermsPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  const isZh = locale === "zh-Hant";

  return (
    <div className="mx-auto max-w-5xl px-4 pb-20 pt-8 md:px-8">
      <Card className="space-y-5 p-7 md:p-9">
        <h1 className="text-3xl font-semibold text-slate-900">{isZh ? "服務條款" : "Terms of Service"}</h1>

        <p className="text-sm leading-7 text-slate-600">
          {isZh
            ? "本服務條款適用於 Naviora 產品與相關服務。使用本服務即表示你同意以下條款。最後更新日期：2026 年 3 月 17 日。"
            : "These Terms of Service apply to Naviora and related services. By using the service, you agree to the terms below. Last updated: March 17, 2026."}
        </p>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "1. 服務內容" : "1. Service Scope"}</h2>
          <p className="text-sm leading-7 text-slate-600">
            {isZh
              ? "Naviora 提供 Rule-based Links 與 QR Routing 建立、管理與分析能力，具體功能會隨版本持續調整。"
              : "Naviora provides rule-based links and QR routing creation, management, and analytics features. Product capabilities may evolve over time."}
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "2. 使用者責任" : "2. User Responsibilities"}</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm leading-7 text-slate-600">
            <li>{isZh ? "不得將本服務用於違法、詐騙或侵權用途。" : "You must not use the service for illegal, fraudulent, or infringing activities."}</li>
            <li>{isZh ? "你需對自己建立與發佈的連結內容負責。" : "You are responsible for the links and content you create and publish."}</li>
            <li>{isZh ? "請妥善保管帳號與存取權限。" : "You are responsible for safeguarding your account and access credentials."}</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "3. 服務可用性與調整" : "3. Availability and Changes"}</h2>
          <p className="text-sm leading-7 text-slate-600">
            {isZh
              ? "我們會持續優化服務，但不保證服務永不中斷。必要時可進行維護、更新或調整功能。"
              : "We continuously improve the service but cannot guarantee uninterrupted availability. Features may be updated, changed, or maintained as needed."}
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "4. 聯絡方式" : "4. Contact"}</h2>
          <p className="text-sm leading-7 text-slate-600">
            {isZh ? "如有條款相關問題，請聯絡：" : "For questions about these terms, contact:"}{" "}
            <a href="mailto:huters@qq.com" className="font-medium text-sky-700 hover:underline">
              huters@qq.com
            </a>
          </p>
        </section>

        <Link href={withLocale(locale, "/")}>
          <Button variant="secondary">{isZh ? "返回首頁" : "Back to home"}</Button>
        </Link>
      </Card>
    </div>
  );
}

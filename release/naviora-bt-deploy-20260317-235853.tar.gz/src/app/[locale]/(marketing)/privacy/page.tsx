import type { Metadata } from "next";
import Link from "next/link";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import type { Locale } from "@/i18n/config";
import { withLocale } from "@/i18n/config";
import { buildPageMetadata } from "@/lib/metadata";

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  return buildPageMetadata(locale, "privacy");
}

export default async function PrivacyPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  const isZh = locale === "zh-Hant";

  return (
    <div className="mx-auto max-w-5xl px-4 pb-20 pt-8 md:px-8">
      <Card className="space-y-5 p-7 md:p-9">
        <h1 className="text-3xl font-semibold text-slate-900">{isZh ? "隱私政策" : "Privacy Policy"}</h1>

        <p className="text-sm leading-7 text-slate-600">
          {isZh
            ? "本隱私政策說明 ZAPS Lab（Naviora）如何蒐集、使用與保護你的資料。最後更新日期：2026 年 3 月 17 日。"
            : "This Privacy Policy explains how ZAPS Lab (Naviora) collects, uses, and protects your data. Last updated: March 17, 2026."}
        </p>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "1. 我們蒐集的資訊" : "1. Information We Collect"}</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm leading-7 text-slate-600">
            <li>{isZh ? "帳號資訊（例如電子郵件）" : "Account details (such as email)."}</li>
            <li>{isZh ? "你建立的連結、規則與 QR 設定資料" : "Link, rule, and QR configuration data you create."}</li>
            <li>{isZh ? "基本使用資料（例如訪問量與操作事件）" : "Basic usage data (such as visits and product events)."}</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "2. 資料用途" : "2. How We Use Data"}</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm leading-7 text-slate-600">
            <li>{isZh ? "提供與維護產品功能" : "To provide and maintain product features."}</li>
            <li>{isZh ? "改善穩定性、體驗與服務品質" : "To improve reliability, experience, and service quality."}</li>
            <li>{isZh ? "必要時進行帳務、通知與客戶支援" : "To support billing, service notices, and customer support when needed."}</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "3. 資料共享與安全" : "3. Sharing and Security"}</h2>
          <p className="text-sm leading-7 text-slate-600">
            {isZh
              ? "除法律要求或為提供服務所需外，我們不會出售你的個人資料。我們採取合理安全措施來保護資料。"
              : "We do not sell your personal data. Data may only be shared when legally required or necessary to operate the service. We apply reasonable safeguards to protect your information."}
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-semibold text-slate-900">{isZh ? "4. 聯絡方式" : "4. Contact"}</h2>
          <p className="text-sm leading-7 text-slate-600">
            {isZh ? "如有隱私相關問題，請聯絡：" : "For privacy-related questions, contact:"}{" "}
            <a href="mailto:huters@qq.com" className="font-medium text-sky-700 hover:underline">
              huters@qq.com
            </a>
          </p>
        </section>

        <Link href={withLocale(locale, "/")}>
          <Button variant="secondary">{isZh ? "返回首頁" : "Back to home"}</Button>
        </Link>
      </Card>
    </div>
  );
}

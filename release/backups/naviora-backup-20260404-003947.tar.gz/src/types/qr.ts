export type QRStatus = "draft" | "active" | "expired" | "archived";
export type QRRuleMode = "none" | "language" | "region" | "device" | "param" | "ab";

export interface QRRuleItem {
  language?: string;
  region?: string;
  os?: string;
  variant?: "A" | "B";
  weight?: number;
  url: string;
}

export interface QRDesign {
  qrStyle?: string;
  borderColor?: string;
  backgroundColor?: string;
  cornerBorderStyle?: string;
  cornerCenterStyle?: string;
  correctionLevel?: "L" | "M" | "Q" | "H";
  logoType?: string;
  logoUrl?: string;
}

export interface QRCodeItem {
  id: string;
  name: string;
  // Public entry path prefixes are reserved as:
  // l = link
  // c = content
  type: "url";
  status: QRStatus;
  defaultUrl: string;
  ruleMode: QRRuleMode;
  languageRules?: Array<{ language: string; url: string }>;
  regionRules?: Array<{ region: string; url: string }>;
  deviceRules?: Array<{ os: string; url: string }>;
  paramRules?: Array<{ key: string; value: string; url: string }>;
  abRules?: Array<{ variant: "A" | "B"; weight: number; url: string }>;
  tracking?: {
    ga4Id?: string;
    metaPixelId?: string;
    enabled: boolean;
  };
  password?: string;
  folderId?: string;
  expiresAt?: string;
  design?: QRDesign;
  scans: number;
  createdAt: string;
  updatedAt: string;
}
